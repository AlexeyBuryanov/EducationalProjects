create procedure insertCategory(IN name varchar(80), IN supcat_id int)
  BEGIN
    INSERT INTO `chip`.`categories` (`id`, `name`, `supercategory_id`) VALUES
        (0, name, supcat_id);
END;

